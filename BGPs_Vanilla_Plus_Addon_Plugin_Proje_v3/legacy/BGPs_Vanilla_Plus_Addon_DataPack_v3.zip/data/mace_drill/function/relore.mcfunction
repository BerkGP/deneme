execute store result storage mace_drill:tmp n int 1 run data get entity @s SelectedItem.components."minecraft:custom_model_data".floats[0]
function mace_drill:relore_do with storage mace_drill:tmp
