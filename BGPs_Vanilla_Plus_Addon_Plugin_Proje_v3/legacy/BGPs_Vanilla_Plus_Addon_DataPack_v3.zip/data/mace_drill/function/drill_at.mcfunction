scoreboard players set #done drill_tmp 1
execute if score #plane drill_tmp matches 0 as @a[tag=drill_user,limit=1] run function mace_drill:plane_y
execute if score #plane drill_tmp matches 1 as @a[tag=drill_user,limit=1] run function mace_drill:plane_x
execute if score #plane drill_tmp matches 2 as @a[tag=drill_user,limit=1] run function mace_drill:plane_z
particle minecraft:poof ~ ~ ~ 0.6 0.6 0.6 0.05 12
particle minecraft:crit ~ ~ ~ 0.8 0.8 0.8 0.3 25
particle minecraft:electric_spark ~ ~ ~ 0.7 0.7 0.7 0.1 15
playsound minecraft:item.mace.smash_ground block @a ~ ~ ~ 0.8 1.5
playsound minecraft:entity.generic.explode block @a ~ ~ ~ 0.3 1.7
