$item modify entity @s weapon.mainhand mace_drill:hp/$(n)
item modify entity @s weapon.mainhand mace_drill:refund
