scoreboard players add #steps drill_tmp 1
execute unless block ~ ~ ~ #mace_drill:passable run return run function mace_drill:ray_hit
execute if score #steps drill_tmp matches ..24 positioned ^ ^ ^0.2 run function mace_drill:ray
