execute as @a if items entity @s container.* minecraft:mace[minecraft:custom_data~{refill:"yes"}] run function mace_drill:refill_scan
execute as @a if items entity @s weapon.offhand minecraft:mace[minecraft:custom_data~{refill:"yes"}] run function mace_drill:refill_scan
kill @e[type=minecraft:marker,tag=drill_old]
tag @e[type=minecraft:marker,tag=drill_target] add drill_old
tag @e[type=minecraft:marker,tag=drill_old] remove drill_target
execute as @a at @s if items entity @s weapon.mainhand minecraft:mace[minecraft:custom_data={drill:"on"}] run function mace_drill:scan
execute as @a if items entity @s container.* minecraft:mace[minecraft:enchantments~[{enchantments:"#mace_drill:drill_only"}]] run function mace_drill:strip_check
execute as @a if items entity @s weapon.offhand minecraft:mace[minecraft:enchantments~[{enchantments:"#mace_drill:drill_only"}]] run function mace_drill:strip_check
