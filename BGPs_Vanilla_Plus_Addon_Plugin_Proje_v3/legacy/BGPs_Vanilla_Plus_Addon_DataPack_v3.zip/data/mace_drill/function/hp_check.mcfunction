execute unless data entity @s SelectedItem.components."minecraft:custom_model_data".floats[0] run return run item modify entity @s weapon.mainhand mace_drill:hp/3500
execute unless data entity @s SelectedItem.components."minecraft:lore"[2] run function mace_drill:relore
