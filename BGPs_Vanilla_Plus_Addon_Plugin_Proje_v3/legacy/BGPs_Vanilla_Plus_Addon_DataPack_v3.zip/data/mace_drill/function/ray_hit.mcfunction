execute if block ~ ~ ~ #mace_drill:protected run return 0
execute align xyz positioned ~0.5 ~0.5 ~0.5 run summon minecraft:marker ~ ~ ~ {Tags:["drill_target","drill_new"]}
scoreboard players operation @e[type=minecraft:marker,tag=drill_new] drill_id = @s drill_id
tag @e[type=minecraft:marker,tag=drill_new] remove drill_new
