scoreboard objectives add drill_id dummy
scoreboard objectives add drill_tmp dummy
