tag @e[type=minecraft:item,distance=..0.8] add dr_pre
loot spawn ~ ~ ~ mine ~ ~ ~ mainhand
tag @e[type=minecraft:item,distance=..0.8,tag=!dr_pre] add dr_keep
setblock ~ ~ ~ air destroy
kill @e[type=minecraft:item,distance=..0.8,tag=!dr_pre,tag=!dr_keep]
execute if score #silk drill_tmp matches 1 run kill @e[type=minecraft:experience_orb,distance=..0.8,nbt={Age:0s}]
tag @e[type=minecraft:item,distance=..0.8] remove dr_pre
tag @e[type=minecraft:item,distance=..0.8] remove dr_keep
