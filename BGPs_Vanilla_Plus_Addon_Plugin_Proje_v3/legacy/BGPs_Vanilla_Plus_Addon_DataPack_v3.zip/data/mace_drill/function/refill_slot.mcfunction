scoreboard players set #hp drill_tmp 0
$execute store result score #hp drill_tmp run data get entity @s Inventory[{Slot:$(s)b}].components."minecraft:custom_model_data".floats[0]
scoreboard players add #hp drill_tmp 500
execute if score #hp drill_tmp matches 3501.. run scoreboard players set #hp drill_tmp 3500
execute store result storage mace_drill:tmp n int 1 run scoreboard players get #hp drill_tmp
$data modify storage mace_drill:tmp c set value "$(c)"
function mace_drill:refill_apply with storage mace_drill:tmp
title @s actionbar {"text": "ᴇᴋsᴋᴀᴠᴀᴛöʀ ᴄᴀɴɪ ʏᴇɴiʟᴇɴᴅi!", "color": "green"}
playsound minecraft:block.smithing_table.use player @s ~ ~ ~ 1 1.2
