$item modify entity @s weapon.mainhand mace_drill:hp/$(n)
