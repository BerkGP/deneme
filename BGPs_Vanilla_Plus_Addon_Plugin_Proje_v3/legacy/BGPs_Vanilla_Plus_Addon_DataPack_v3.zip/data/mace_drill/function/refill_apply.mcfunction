$item modify entity @s $(c) mace_drill:hp/$(n)
$item modify entity @s $(c) mace_drill:clear_marker
