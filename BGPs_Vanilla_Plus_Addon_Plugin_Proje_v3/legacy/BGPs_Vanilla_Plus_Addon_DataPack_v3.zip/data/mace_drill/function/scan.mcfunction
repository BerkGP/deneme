function mace_drill:hp_check
execute unless score @s drill_id matches 1.. run function mace_drill:assign_id
scoreboard players set #steps drill_tmp 0
execute anchored eyes positioned ^ ^ ^ anchored feet run function mace_drill:ray
