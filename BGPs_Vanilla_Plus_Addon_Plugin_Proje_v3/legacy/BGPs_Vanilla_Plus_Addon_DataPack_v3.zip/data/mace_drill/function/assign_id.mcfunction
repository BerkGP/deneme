scoreboard players add #next drill_tmp 1
scoreboard players operation @s drill_id = #next drill_tmp
