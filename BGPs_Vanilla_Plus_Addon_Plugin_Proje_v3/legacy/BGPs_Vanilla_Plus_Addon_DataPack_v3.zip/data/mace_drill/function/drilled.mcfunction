advancement revoke @s only mace_drill:mined
execute unless items entity @s weapon.mainhand minecraft:mace[minecraft:custom_data={drill:"on"}] run return 0
tag @s add drill_user
scoreboard players set #plane drill_tmp 2
execute if entity @s[y_rotation=45..135] run scoreboard players set #plane drill_tmp 1
execute if entity @s[y_rotation=-135..-45] run scoreboard players set #plane drill_tmp 1
execute if entity @s[x_rotation=45..90] run scoreboard players set #plane drill_tmp 0
execute if entity @s[x_rotation=-90..-45] run scoreboard players set #plane drill_tmp 0
scoreboard players set #silk drill_tmp 0
execute if items entity @s weapon.mainhand minecraft:mace[minecraft:enchantments~[{enchantments:"minecraft:silk_touch"}]] run scoreboard players set #silk drill_tmp 1
scoreboard players set #done drill_tmp 0
execute as @e[type=minecraft:marker,tag=drill_target] if score @s drill_id = @a[tag=drill_user,limit=1] drill_id at @s if block ~ ~ ~ #mace_drill:passable run function mace_drill:drill_at
execute if score #done drill_tmp matches 0 as @e[type=minecraft:marker,tag=drill_old] if score @s drill_id = @a[tag=drill_user,limit=1] drill_id at @s if block ~ ~ ~ #mace_drill:passable run function mace_drill:drill_at
execute if score #done drill_tmp matches 1 run function mace_drill:use_hp
tag @s remove drill_user
