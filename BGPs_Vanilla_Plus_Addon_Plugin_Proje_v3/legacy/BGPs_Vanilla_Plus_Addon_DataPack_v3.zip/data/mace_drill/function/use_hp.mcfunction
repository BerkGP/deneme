execute store success score #ok drill_tmp if data entity @s SelectedItem.components."minecraft:custom_model_data".floats[0]
execute unless score #ok drill_tmp matches 1 run return 0
execute store result score #hp drill_tmp run data get entity @s SelectedItem.components."minecraft:custom_model_data".floats[0]
scoreboard players remove #hp drill_tmp 5
execute if score #hp drill_tmp matches ..0 run scoreboard players set #hp drill_tmp 0
execute store result storage mace_drill:tmp n int 1 run scoreboard players get #hp drill_tmp
function mace_drill:apply with storage mace_drill:tmp
execute if score #hp drill_tmp matches 0 run title @s actionbar {"text":"ᴇᴋsᴋᴀᴠᴀᴛöʀ ᴄᴀɴɪ ᴛüᴋᴇɴᴅi!","color":"red"}
