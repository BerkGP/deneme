$item modify entity @s $(slot) mace_drill:strip
tag @s add drill_stripped
