# ucus hasari gogusluğu kiracakti: gogusluk oldugu gibi korunur, 1 can elytradan duser
scoreboard players set #dmg ae_t 0
execute store result score #dmg ae_t run data get entity @s equipment.chest.components."minecraft:damage"
scoreboard players add #ed ae_t 1
scoreboard players set #hp ae_t 432
scoreboard players operation #hp ae_t -= #ed ae_t
execute store result storage armored_elytra:io m.d int 1 run scoreboard players get #dmg ae_t
execute store result storage armored_elytra:io m.e int 1 run scoreboard players get #ed ae_t
execute store result storage armored_elytra:io m.h int 1 run scoreboard players get #hp ae_t
execute unless data storage armored_elytra:io item.components."minecraft:lore"[2] run data modify storage armored_elytra:io item.components."minecraft:lore" append value {text:""}
data modify storage armored_elytra:io item.components."minecraft:equippable".equip_sound set value {sound_id:"armored_elytra:silent"}
function armored_elytra:commit_macro with storage armored_elytra:io m
function armored_elytra:item_save with storage armored_elytra:io m
scoreboard players set @s ae_fsave 1
tag @s add ae_broke
