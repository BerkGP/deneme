execute as @a[tag=ae_broke] at @s run function armored_elytra:break_finish
execute as @a at @s run function armored_elytra:player
