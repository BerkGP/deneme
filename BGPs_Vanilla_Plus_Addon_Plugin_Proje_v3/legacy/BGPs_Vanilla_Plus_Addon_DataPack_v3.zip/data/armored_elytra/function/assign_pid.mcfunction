scoreboard players add #next ae_pid 1
scoreboard players operation @s ae_pid = #next ae_pid
