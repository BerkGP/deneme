$data modify storage armored_elytra:io item.components."minecraft:damage" set value $(d)
$data modify storage armored_elytra:io item.components."minecraft:custom_data".ae_ed set value $(e)
$data modify storage armored_elytra:io item.components."minecraft:lore"[2] set value {text:"",italic:false,extra:[{text:"ᴇʟiᴛʀᴀ ᴄᴀɴɪ: ",color:"gray"},{text:"$(h)",color:"aqua"},{text:" / 432",color:"gray"}]}
