scoreboard players set #dmg ae_t 0
scoreboard players set #ed ae_t 0
scoreboard players set #chg ae_t 0
execute store result score #dmg ae_t run data get entity @s equipment.chest.components."minecraft:damage"
execute store result score #ed ae_t run data get entity @s equipment.chest.components."minecraft:custom_data".ae_ed
# eski (veri yazilmamis) zirhli elytralari tek seferlik hazirla
execute unless data entity @s equipment.chest.components."minecraft:custom_data".ae_ed run scoreboard players set #chg ae_t 1
execute if score @s ae_valid matches 1 run function armored_elytra:delta
function armored_elytra:xp
execute if score #chg ae_t matches 1 run function armored_elytra:commit
execute if score #ed ae_t matches 431.. run function armored_elytra:elytra_off
scoreboard players operation @s ae_last = #dmg ae_t
scoreboard players set @s ae_valid 1
