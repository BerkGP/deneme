scoreboard players set #c5 ae_t 5
scoreboard players set #c81 ae_t 81
scoreboard players set #c2 ae_t 2
scoreboard players operation #xpt ae_t = #L ae_t
scoreboard players operation #xpt ae_t *= #L ae_t
scoreboard players operation #xpt ae_t *= #c5 ae_t
scoreboard players operation #b ae_t = #L ae_t
scoreboard players operation #b ae_t *= #c81 ae_t
scoreboard players operation #xpt ae_t -= #b ae_t
scoreboard players add #xpt ae_t 720
scoreboard players operation #xpt ae_t /= #c2 ae_t
