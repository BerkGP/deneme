$data modify storage armored_elytra:brk p$(pid) set from storage armored_elytra:io el
