scoreboard players set #c6 ae_t 6
scoreboard players operation #xpt ae_t = #L ae_t
scoreboard players operation #xpt ae_t *= #L ae_t
scoreboard players operation #b ae_t = #L ae_t
scoreboard players operation #b ae_t *= #c6 ae_t
scoreboard players operation #xpt ae_t += #b ae_t
