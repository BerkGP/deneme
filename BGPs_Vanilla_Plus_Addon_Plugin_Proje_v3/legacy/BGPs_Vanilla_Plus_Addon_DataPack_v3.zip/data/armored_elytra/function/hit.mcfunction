advancement revoke @s only armored_elytra:hit
scoreboard players set @s ae_hit 1
