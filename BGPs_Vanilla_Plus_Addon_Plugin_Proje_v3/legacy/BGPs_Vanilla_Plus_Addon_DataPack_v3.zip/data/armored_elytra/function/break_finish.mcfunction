tag @s remove ae_broke
data remove storage armored_elytra:io item
execute store result storage armored_elytra:io m.pid int 1 run scoreboard players get @s ae_pid
function armored_elytra:chest_load with storage armored_elytra:io m
execute unless data storage armored_elytra:io item.id run return run scoreboard players set @s ae_fsave 0
execute if items entity @s armor.chest * run return run scoreboard players set @s ae_fsave 0
function armored_elytra:install_item
execute if score @s ae_fsave matches 0 run title @s actionbar {"text":"ɢöğüsʟüᴋ ᴋɪʀɪʟᴅɪ! ᴇʟiᴛʀᴀ ɢöğüs sʟᴏᴛᴜɴᴀ ɢᴇçᴛi.","color":"yellow"}
scoreboard players set @s ae_fsave 0
