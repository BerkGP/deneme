scoreboard players operation #ed ae_t += #delta ae_t
scoreboard players operation #dmg ae_t = @s ae_last
scoreboard players set #chg ae_t 1
