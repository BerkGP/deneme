execute store result score #L ae_t run experience query @s levels
execute store result score #P ae_t run experience query @s points
execute if score #L ae_t matches ..16 run function armored_elytra:xp_t1
execute if score #L ae_t matches 17..31 run function armored_elytra:xp_t2
execute if score #L ae_t matches 32.. run function armored_elytra:xp_t3
scoreboard players operation #xpt ae_t += #P ae_t
