scoreboard players set #c9 ae_t 9
scoreboard players set #c325 ae_t 325
scoreboard players set #c2 ae_t 2
scoreboard players operation #xpt ae_t = #L ae_t
scoreboard players operation #xpt ae_t *= #L ae_t
scoreboard players operation #xpt ae_t *= #c9 ae_t
scoreboard players operation #b ae_t = #L ae_t
scoreboard players operation #b ae_t *= #c325 ae_t
scoreboard players operation #xpt ae_t -= #b ae_t
scoreboard players add #xpt ae_t 4440
scoreboard players operation #xpt ae_t /= #c2 ae_t
