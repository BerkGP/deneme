scoreboard players operation #delta ae_t = #dmg ae_t
scoreboard players operation #delta ae_t -= @s ae_last
# SADECE: tam 1 hasar + oyuncu hasar almamis + oyuncu ucuyor => ucus hasari (elytraya yazilir)
# baska her durum (yururken, darbe, 2+ hasar...) klasik gogus hasaridir, dokunulmaz
execute if score #delta ae_t matches 1 if score #hurt ae_t matches 0 if score @s ae_avirec matches 1.. run function armored_elytra:flight
execute if score #delta ae_t matches ..-1 if score #sneak ae_t matches 1 if score #ed ae_t matches 1.. run function armored_elytra:repair_to_elytra
