data modify storage armored_elytra:io item set from entity @s equipment.chest
data modify storage armored_elytra:io m.x set value 431
function armored_elytra:make_elytra with storage armored_elytra:io m
data remove storage armored_elytra:io item.components."minecraft:glider"
data remove storage armored_elytra:io item.components."minecraft:equippable"
data remove storage armored_elytra:io item.components."minecraft:lore"
data remove storage armored_elytra:io item.components."minecraft:custom_data"
function armored_elytra:install_item
summon item ~ ~ ~ {Tags:["ae_tmp2"],PickupDelay:0s,Item:{id:"minecraft:stone",count:1}}
data modify entity @n[type=item,tag=ae_tmp2,distance=..3] Item set from storage armored_elytra:io el
kill @n[type=item,tag=ae_tmp2,distance=..3,nbt={Item:{id:"minecraft:stone"}}]
tag @n[type=item,tag=ae_tmp2,distance=..3] remove ae_tmp2
playsound minecraft:entity.item.break player @a ~ ~ ~ 1 0.8
title @s actionbar {"text":"ᴇʟiᴛʀᴀ ᴋɪʀɪʟᴅɪ! ɢöğüsʟüᴋ ʏᴇʀiɴᴅᴇ ᴋᴀʟᴅɪ, ᴋɪʀɪᴋ ᴇʟiᴛʀᴀ ᴇɴᴠᴀɴᴛᴇʀiɴᴇ ɢᴇʟᴅi.","color":"red"}
