$experience add @s -$(u) points
