scoreboard players set #m1 ae_t -1
scoreboard players operation #k ae_t = #delta ae_t
scoreboard players operation #k ae_t *= #m1 ae_t
scoreboard players operation #r ae_t = #k ae_t
scoreboard players operation #r ae_t < #ed ae_t
scoreboard players operation #ed ae_t -= #r ae_t
scoreboard players operation #dmg ae_t += #r ae_t
scoreboard players set #chg ae_t 1
