$data modify storage armored_elytra:io item set from storage armored_elytra:brk p$(pid)
$data remove storage armored_elytra:brk p$(pid)
