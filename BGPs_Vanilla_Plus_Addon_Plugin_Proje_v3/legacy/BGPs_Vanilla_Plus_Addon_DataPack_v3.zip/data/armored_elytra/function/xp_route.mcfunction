# gogus tamir edecek hasarli esya kalmayinca oyuncuya kalan tecrube -> elytraya
scoreboard players operation #gain ae_t = #xpt ae_t
scoreboard players operation #gain ae_t -= @s ae_xplast
execute unless score #gain ae_t matches 1.. run return 0
scoreboard players set #c2 ae_t 2
scoreboard players operation #r ae_t = #gain ae_t
scoreboard players operation #r ae_t *= #c2 ae_t
scoreboard players operation #r ae_t < #ed ae_t
scoreboard players operation #ed ae_t -= #r ae_t
scoreboard players operation #used ae_t = #r ae_t
scoreboard players add #used ae_t 1
scoreboard players operation #used ae_t /= #c2 ae_t
scoreboard players set #chg ae_t 1
execute store result storage armored_elytra:io m.u int 1 run scoreboard players get #used ae_t
function armored_elytra:xp_take with storage armored_elytra:io m
scoreboard players set @s ae_skip 1
