function armored_elytra:xp_total
execute if score @s ae_skip matches 1 run return run function armored_elytra:xp_snap
execute if score @s ae_valid matches 1 if score #ed ae_t matches 1.. if data entity @s equipment.chest.components."minecraft:enchantments"."minecraft:mending" run function armored_elytra:xp_route
scoreboard players operation @s ae_xplast = #xpt ae_t
