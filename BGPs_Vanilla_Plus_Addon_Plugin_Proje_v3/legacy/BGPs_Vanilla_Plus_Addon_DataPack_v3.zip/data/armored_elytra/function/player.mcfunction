scoreboard players add @s ae_sneak 0
scoreboard players add @s ae_sneakl 0
scoreboard players add @s ae_hurt 0
scoreboard players add @s ae_hurtl 0
scoreboard players add @s ae_avi 0
scoreboard players add @s ae_avil 0
scoreboard players add @s ae_avirec 0
scoreboard players add @s ae_hit 0
# egilme
scoreboard players set #sneak ae_t 0
scoreboard players operation #t ae_t = @s ae_sneak
scoreboard players operation #t ae_t -= @s ae_sneakl
execute if score #t ae_t matches 1.. run scoreboard players set #sneak ae_t 1
scoreboard players operation @s ae_sneakl = @s ae_sneak
# hasar aldi mi? (3 sinyal: damage_taken istatistigi + hit advancement)
scoreboard players set #hurt ae_t 0
scoreboard players operation #t ae_t = @s ae_hurt
scoreboard players operation #t ae_t -= @s ae_hurtl
execute if score #t ae_t matches 1.. run scoreboard players set #hurt ae_t 1
scoreboard players operation @s ae_hurtl = @s ae_hurt
execute if score @s ae_hit matches 1.. run scoreboard players set #hurt ae_t 1
execute if score @s ae_hit matches 1.. run scoreboard players remove @s ae_hit 1
# ucuyor mu? (elytra ile ucus mesafesi artiyor mu)
execute if score @s ae_avirec matches 1.. run scoreboard players remove @s ae_avirec 1
scoreboard players operation #t ae_t = @s ae_avi
scoreboard players operation #t ae_t -= @s ae_avil
execute if score #t ae_t matches 1.. run scoreboard players set @s ae_avirec 60
scoreboard players operation @s ae_avil = @s ae_avi
# zirhli elytra giyiyor mu?
scoreboard players set #w ae_t 0
execute if items entity @s armor.chest #armored_elytra:chestplates if data entity @s equipment.chest.components."minecraft:glider" run scoreboard players set #w ae_t 1
execute if score #w ae_t matches 1 run function armored_elytra:worn
execute if score #w ae_t matches 0 run scoreboard players set @s ae_valid 0
