summon item ~ ~ ~ {Tags:["ae_tmp"],PickupDelay:32767s,Item:{id:"minecraft:stone",count:1}}
data modify entity @n[type=item,tag=ae_tmp,distance=..3] Item set from storage armored_elytra:io item
# esya gercekten yazildiysa (hala tas degilse) slota koy; yazilamadiysa HICBIR sey degistirme
execute unless entity @n[type=item,tag=ae_tmp,distance=..3,nbt={Item:{id:"minecraft:stone"}}] run item replace entity @s armor.chest from entity @n[type=item,tag=ae_tmp,distance=..3] contents
kill @n[type=item,tag=ae_tmp,distance=..3]
