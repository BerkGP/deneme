scoreboard players set @s ae_skip 0
scoreboard players operation @s ae_xplast = #xpt ae_t
