advancement revoke @s only armored_elytra:chest_break
execute unless items entity @s armor.chest #armored_elytra:chestplates run return 0
execute unless data entity @s equipment.chest.components."minecraft:glider" run return 0
execute unless score @s ae_pid matches 1.. run function armored_elytra:assign_pid
data modify storage armored_elytra:io item set from entity @s equipment.chest
scoreboard players set #ed ae_t 0
execute store result score #ed ae_t run data get entity @s equipment.chest.components."minecraft:custom_data".ae_ed
execute store result storage armored_elytra:io m.pid int 1 run scoreboard players get @s ae_pid
scoreboard players set @s ae_fsave 0
execute if score @s ae_avirec matches 1.. if score @s ae_hit matches 0 if score #ed ae_t matches ..430 run return run function armored_elytra:flight_save
execute store result storage armored_elytra:io m.x int 1 run scoreboard players get #ed ae_t
function armored_elytra:make_elytra with storage armored_elytra:io m
function armored_elytra:chest_save with storage armored_elytra:io m
tag @s add ae_broke
