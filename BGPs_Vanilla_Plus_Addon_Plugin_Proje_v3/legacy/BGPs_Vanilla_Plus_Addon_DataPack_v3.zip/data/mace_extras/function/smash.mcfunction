advancement revoke @s only mace_extras:smash
execute unless items entity @s weapon.mainhand minecraft:mace run return 0
scoreboard players set #a mace_fd 0
scoreboard players set #b mace_fd 0
execute store result score #a mace_fd run data get entity @s fall_distance 10
execute store result score #b mace_fd run data get entity @s FallDistance 10
scoreboard players operation #a mace_fd > #b mace_fd
execute unless score #a mace_fd matches 16.. run return 0
tag @s add mace_user
execute at @s run particle minecraft:explosion ~ ~0.2 ~ 1.5 0.1 1.5 0 8
execute at @s run particle minecraft:crit ~ ~0.5 ~ 2 0.3 2 0.2 40
execute at @s run playsound minecraft:item.mace.smash_ground_heavy player @a ~ ~ ~ 1 1
execute at @s run effect give @e[distance=..4,tag=!mace_user,type=!minecraft:item,type=!minecraft:experience_orb] minecraft:slowness 3 2
execute at @s run effect give @e[distance=..4,tag=!mace_user,type=!minecraft:item,type=!minecraft:experience_orb] minecraft:weakness 3 1
tag @s remove mace_user
