scoreboard objectives add mace_fd dummy
